=== Awesome SSL ===
Contributors: ejslondon
Donate link: https://ejs
ondon.com/awesome-ssl/
Tags: SSL, security, secure, wordpress
Requires at least: 4.7
Tested up to: 5.7
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Awesome SSL is the easiest way to add an SSL Certificate to your WordPress Website. After you have issued an SSL Certificate to your website you'll find that it still says 'not secure' by default. That's because your website is automatically connecting through HTTP instead of HTTPS, but don't worry, this simple plugin fixes that issue and makes SSL work again! It's as simple as activating a plugin.
== Installation ==
* Install plugin from Plugins < Add New < Awesome SSL or download file from WordPress.org
* Activate Plugin
* Configure any extra settings you want
* You're good to go!
== Changelog ==
= 1.0.1 =
* Fixed error appearing on attempting to activate plugin from WordPress.org directory returning an unexpected error due to syntax.
= 1.0.0 =
* Initial Release
= 0.0.1 =
* Initial Beta Release
== Upgrade Notice ==
